固件烧录方法请参考《ATK-ESP8266模块用户手册》第2.6小节“固件烧录”。

SHA256文件校验：
安信可提供固件.bin：61a0bec4bb41140a1c1fde07a3be6d1c1e26c9f625b7befafec1e82d3f4692b7